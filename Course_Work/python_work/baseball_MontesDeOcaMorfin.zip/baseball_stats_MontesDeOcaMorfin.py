# Jose Montes De Oca Morfin
# Homework 6 Baseball Stats
# Library of functions


def print_banner_block(width,message):
    print("*" * width)
    print(message.center(width))
    print("*" * width)
    print("")

def print_welcome():
    print_banner_block(80,"BASEBALL STATISTICS")
    print("Welcome to Baseball Statistics. This program reads  a file that contains statistics for")
    print("various players from the 2021 season. It will then calculate and print statistics for")
    print("hitters and then for pitchers.")
    print("")

def print_goodbye():
    print_banner_block(80,"THANKS. SEE YOU AT THE BALLPARK.")
    
def batting_average(hits,at_bats):
    avg = (hits / at_bats)
    return avg

def on_base_percentage(hits,walks,hit_by_pitch,at_bats,sacrifices):
    obp = (hits + walks + hit_by_pitch) / (at_bats + walks + hit_by_pitch + sacrifices)
    return obp

def home_run_ratio(at_bats,home_runs):
    hrr = at_bats / home_runs
    return hrr

def slugging_percentage(tot_number_bases,at_bats):
    sp = tot_number_bases / at_bats
    return sp
    
def isolated_power(slugging_percentage,batting_average):
    iso = slugging_percentage - batting_average
    return iso

def on_base_per_slugging(on_base_percentage,slugging_percentage):
    ops = on_base_percentage + slugging_percentage
    return ops 

def earned_run_average(earned_runs_allowed,innings_pitched):
    era = 9 * (earned_runs_allowed / innings_pitched)
    return era

def walks_and_hits_per_innings_pitched(walks,hits,innings_pitched):
    whip = (walks + hits) / innings_pitched
    return whip

