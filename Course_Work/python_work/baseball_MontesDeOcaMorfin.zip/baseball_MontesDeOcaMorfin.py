# Jose Montes De Oca Morfin
# Homework 6 Baseball Statistics
# Main Code

from baseball_hw_functions import print_banner_block, print_welcome,print_goodbye,batting_average,on_base_percentage,home_run_ratio,slugging_percentage,isolated_power,on_base_per_slugging,earned_run_average,walks_and_hits_per_innings_pitched
#Import functions from finctions file

print_welcome()

fname = input("Enter name of stats file: ")
success = False

while success == False: # test to make sure an actual file is input 
    try:
        fvar = open(fname,"r")
        success = True
    except Exception as e:
        print("The following error occured: ")
        print("         ", e)
        print("")
        fname = input("Enter the name of stats file: ")

print("")
        
line = fvar.readline()  # start reading file 

print("***Batting Statistics***".center(80))
print("")
print("%s%14s%16s%8s%8s%8s%8s%8s" % ("First Name","Last Name","Avg","OBP","HRR","SP","ISO","OPS"))
print("-" * 80)

while line:  # read through file only reading lines that dont start with P
    line = line.strip().lower()
    if line != "p":
        first_name = fvar.readline().strip()
        last_name = fvar.readline().strip()
        at_bats = int(fvar.readline())
        runs = int(fvar.readline())
        hits = int(fvar.readline())
        doubles = int(fvar.readline())
        triples = int(fvar.readline())
        home_runs = int(fvar.readline())
        runs_batted_in = int(fvar.readline())
        walks = int(fvar.readline())
        strikeouts = int(fvar.readline())
        stolen_bases = int(fvar.readline())
        sacrifices = 0
        hit_by_pitch = 0
        singles = hits - doubles - triples - home_runs
        tot_number_bases = singles + 2 * doubles + 3 * triples + 4 * home_runs
        obp = on_base_percentage(hits,walks,hit_by_pitch,at_bats,sacrifices) # use functions to get calculations 
        avg = batting_average(hits,at_bats)
        hrr = home_run_ratio(at_bats,home_runs)
        sp = slugging_percentage(tot_number_bases,at_bats)
        iso = isolated_power(sp,avg)
        ops = on_base_per_slugging(obp,sp)
        print("%-15s%-20s%.3f%8.3f%8.2f%8.3f%8.3f%8.3f" % (first_name,last_name, avg, obp, hrr, sp, iso, ops))
    else:
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
    line = fvar.readline() 
    
    
fvar.close()      # finished reading file first time with only batters 


fvar = open(fname,"r")
line = fvar.readline()  # open file again and start reading again 

print("")
print("")
print("***Pitching Statistics ***".center(40))
print("")
print("%s%14s%15s%7s" % ("First Name","Last Name","ERA","WHIP"))
print("-" * 47)


while line:    # read only file lines that do start with P this time 
    line = line.strip().lower()
    if line == "p":
        first_name = fvar.readline().strip()
        last_name = fvar.readline().strip()
        wins = int(fvar.readline())
        losses = int(fvar.readline())
        innings_pitched = float(fvar.readline())
        hits_allowed = int(fvar.readline())
        earned_runs = int(fvar.readline())
        home_runs = int(fvar.readline())
        walks = int(fvar.readline())
        strikeouts = int(fvar.readline())
        era = earned_run_average(earned_runs,innings_pitched)   # use functions to get calculations 
        whip = walks_and_hits_per_innings_pitched(walks,hits_allowed,innings_pitched)                                   
        print("%-15s%-15s%9.2f%7.2f" % (first_name, last_name, era, whip))
        
    else:
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
        fvar.readline()
    line = fvar.readline()




fvar.close()   # close file again

    
print("")
print_goodbye()
